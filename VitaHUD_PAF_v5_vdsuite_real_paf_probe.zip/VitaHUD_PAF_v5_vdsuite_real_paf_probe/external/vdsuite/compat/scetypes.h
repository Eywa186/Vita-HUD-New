#pragma once
/*
 * Compatibility bridge for VDSuite PAF headers in VitaSDK builds.
 */
#include <psp2/types.h>

#ifndef SCE_NULL
#define SCE_NULL 0
#endif
