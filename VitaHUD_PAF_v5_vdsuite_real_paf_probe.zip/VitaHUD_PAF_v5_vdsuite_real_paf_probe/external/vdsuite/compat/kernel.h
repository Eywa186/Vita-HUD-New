#pragma once
/*
 * Compatibility bridge for VDSuite PAF headers in VitaSDK builds.
 * VDSuite PAF headers use old shorthand includes like <kernel.h>.
 */
#include <psp2/types.h>
#include <psp2/kernel/types.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
