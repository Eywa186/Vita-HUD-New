This directory contains licenses of third-party softwares used by Vita Development Suite CMake Modules.
