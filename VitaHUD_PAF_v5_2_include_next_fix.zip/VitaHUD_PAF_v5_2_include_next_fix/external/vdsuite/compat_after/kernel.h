#pragma once
/* include_next compatibility bridge. */
#include <psp2/types.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
