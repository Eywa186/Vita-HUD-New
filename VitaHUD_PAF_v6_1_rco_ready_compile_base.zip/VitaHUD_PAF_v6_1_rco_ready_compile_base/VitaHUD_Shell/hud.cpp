#include "hud.h"
#include "profile.h"

namespace vitahud
{
    using namespace paf;

    /*
     * v6.1 RCO-ready compile base:
     *
     * v6.0 proved this VDSuite header package does NOT expose:
     *   paf::common::MainThreadCallList
     *
     * So this version removes that dependency and keeps a clean real-VDSuite
     * compile base for the next correct path:
     *
     *   Plugin/resource/RCO/template injection.
     *
     * v5.9 direct widget creation compiled but did not show on Vita.
     * Therefore direct new Text(root, 0) is not enough.
     */
    static paf::widget::Widget *s_hudRoot = SCE_NULL;
    static paf::widget::Text *s_hudText = SCE_NULL;

    static SceUInt64 s_lastCacheTick = 0;
    static char s_cachedLine[128] = "VITAHUD RCO READY";

    static int AppendText(char *out, int pos, const char *text)
    {
        while (*text && pos < 126) {
            out[pos++] = *text++;
        }

        out[pos] = 0;
        return pos;
    }

    static int AppendInt(char *out, int pos, int value)
    {
        char tmp[16];
        int n = 0;
        int i;

        if (value < 0 && pos < 126) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return pos;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (i = n - 1; i >= 0 && pos < 126; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
        return pos;
    }

    static void BuildTime(char *out, int *pos)
    {
        SceDateTime dt;
        sceRtcGetCurrentClockLocalTime(&dt);

        int hour = dt.hour;
        int minute = dt.minute;

        if (*pos + 5 >= 127) {
            return;
        }

        out[(*pos)++] = '0' + ((hour / 10) % 10);
        out[(*pos)++] = '0' + (hour % 10);
        out[(*pos)++] = ':';
        out[(*pos)++] = '0' + ((minute / 10) % 10);
        out[(*pos)++] = '0' + (minute % 10);
        out[*pos] = 0;
    }

    static void ToSceWChar16(const char *src, SceWChar16 *dst, int maxChars)
    {
        int i = 0;

        while (src[i] && i < maxChars - 1) {
            dst[i] = (SceWChar16)(unsigned char)src[i];
            i++;
        }

        dst[i] = 0;
    }

    void Hud::Create()
    {
        /*
         * Do not create direct widgets here.
         *
         * v5.9 compiled but did not display, so the next real visible path is:
         *
         *   1. Load plugin/RCO resource.
         *   2. Get/create root widget from resource element.
         *   3. Add widget from template.
         *   4. Get text widget by hash.
         *   5. Set label.
         */
        s_hudRoot = SCE_NULL;
        s_hudText = SCE_NULL;
    }

    void Hud::Destroy()
    {
        s_hudRoot = SCE_NULL;
        s_hudText = SCE_NULL;
    }

    void Hud::SetVisible(bool visible)
    {
        (void)visible;
    }

    void Hud::SetPosition(int position)
    {
        (void)position;
    }

    void Hud::UpdateCachedText()
    {
        SceRtcTick tick;
        sceRtcGetCurrentTick(&tick);

        if (s_lastCacheTick != 0 && tick.tick - s_lastCacheTick < 500000) {
            return;
        }

        s_lastCacheTick = tick.tick;

        int battery = scePowerGetBatteryLifePercent();

        char line[128];
        int pos = 0;

        pos = AppendText(line, pos, "VITAHUD RCO READY  ");

        if (g_settings.showBattery) {
            pos = AppendText(line, pos, "BAT ");
            pos = AppendInt(line, pos, battery);
            pos = AppendText(line, pos, "%  ");
        }

        if (g_settings.showTime) {
            BuildTime(line, &pos);
        }

        for (int i = 0; i < 128; i++) {
            s_cachedLine[i] = line[i];

            if (line[i] == 0) {
                break;
            }
        }
    }

    void Hud::ApplyText()
    {
        /*
         * Compile-check real VDSuite WString/Text symbols only when a real
         * template text widget exists.
         */
        if (!s_hudText) {
            return;
        }

        SceWChar16 wbuf[128];
        ToSceWChar16(s_cachedLine, wbuf, 128);

        paf::WString wtext(wbuf);
        s_hudText->SetLabel(&wtext);
    }

    void Hud::Update(void *arg)
    {
        (void)arg;

        if (!g_settings.hudEnabled) {
            return;
        }

        UpdateCachedText();
        ApplyText();
    }
}
