# VitaHUD PAF v5 — VDSuite Real PAF Probe

This package bundles the VDSuite files you uploaded.

## Confirmed inside VDSuite

```txt
sdk/target/include/vdsuite/user/paf.h
sdk/target/include/vdsuite/user/paf/*
sdk/target/lib/vdsuite/libScePaf*_stub_weak.a
```

## What v5 does

- Bundles VDSuite under:

```txt
external/vdsuite/sdk/
```

- Adds compatibility bridge headers for old VDSuite shorthand includes:

```txt
external/vdsuite/compat/kernel.h
external/vdsuite/compat/scetypes.h
```

- CMake now includes:

```txt
external/vdsuite/sdk/target/include/vdsuite/user
external/vdsuite/sdk/target/include/vdsuite/common
external/vdsuite/sdk/target/lib/vdsuite
```

- Links the PAF stubs matching PSVshellPlus style:

```txt
ScePafToplevel_stub_weak
ScePafStdc_stub_weak
ScePafCommon_stub_weak
ScePafWidget_stub_weak
ScePafThread_stub_weak
ScePafResource_stub_weak
ScePafGraphics_stub_weak
ScePafMisc_stub_weak
```

## Important

This is a real VDSuite probe.

If it fails, that is good data: the next error will tell us exactly which API names need to be adapted.

The likely next issue is that VDSuite PAF uses `paf::widget::*`, while the PSVshellPlus code style uses `paf::ui::*`.


## v5.1

Fixed VDSuite shorthand include bridge:

```txt
external/vdsuite/compat/ctrl.h
```

This maps:

```cpp
#include_next <ctrl.h>
```

to:

```cpp
#include <psp2/ctrl.h>
```

Also added likely bridge headers for display, power, rtc, appmgr, iofilemgr, threadmgr, and modulemgr.


## v5.2

Fixed `#include_next <ctrl.h>` behavior.

VDSuite `common/ctrl.h` uses:

```cpp
#include_next <ctrl.h>
```

So the compatibility bridge must appear **after** the VDSuite common include path.

Added:

```txt
external/vdsuite/compat_after/
```

CMake include order is now:

```txt
compat
vdsuite/user
vdsuite/common
compat_after
```


## v5.3

Fixed `kernel.h` bridge.

Removed invalid include:

```cpp
#include <psp2/kernel/types.h>
```

Replaced with:

```cpp
#include <psp2/types.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
```


## v5.4

Fixed missing VDSuite graphics shorthand header:

```txt
gxm.h
```

Added bridge:

```cpp
#include <psp2/gxm.h>
```

in:

```txt
external/vdsuite/compat/gxm.h
external/vdsuite/compat_after/gxm.h
```
