#pragma once
/* VitaSDK shorthand compatibility bridge. */
#include <psp2/kernel/modulemgr.h>
