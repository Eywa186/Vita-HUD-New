#pragma once
/*
 * Compatibility bridge for VDSuite common/ctrl.h.
 * VDSuite uses:
 *   #include_next <ctrl.h>
 * but VitaSDK provides:
 *   <psp2/ctrl.h>
 */
#include <psp2/ctrl.h>
