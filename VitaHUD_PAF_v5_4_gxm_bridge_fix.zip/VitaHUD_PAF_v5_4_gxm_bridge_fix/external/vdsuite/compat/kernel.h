#pragma once
/*
 * VDSuite shorthand kernel.h bridge for VitaSDK.
 *
 * VitaSDK does not provide:
 *   <psp2/kernel/types.h>
 *
 * Use:
 *   <psp2/types.h>
 * plus kernel module/thread headers.
 */
#include <psp2/types.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>

#ifndef SCE_KERNEL_START_SUCCESS
#define SCE_KERNEL_START_SUCCESS 0
#endif

#ifndef SCE_KERNEL_STOP_SUCCESS
#define SCE_KERNEL_STOP_SUCCESS 0
#endif
