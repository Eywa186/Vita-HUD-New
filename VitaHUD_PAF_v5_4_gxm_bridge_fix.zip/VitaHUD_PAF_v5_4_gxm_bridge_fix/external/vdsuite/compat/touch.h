#pragma once
/* VitaSDK shorthand compatibility bridge. */
#include <psp2/touch.h>
