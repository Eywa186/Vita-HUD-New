#pragma once
/* VitaSDK shorthand compatibility bridge. */
#include <psp2/display.h>
