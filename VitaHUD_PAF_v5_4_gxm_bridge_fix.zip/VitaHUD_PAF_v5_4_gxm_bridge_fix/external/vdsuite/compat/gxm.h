#pragma once
/*
 * VDSuite shorthand gxm.h bridge for VitaSDK.
 *
 * VDSuite PAF graphics headers use:
 *   #include <gxm.h>
 *
 * VitaSDK provides:
 *   #include <psp2/gxm.h>
 */
#include <psp2/gxm.h>
