#pragma once
/* include_next compatibility bridge. */
#include <psp2/types.h>
#ifndef SCE_NULL
#define SCE_NULL 0
#endif
