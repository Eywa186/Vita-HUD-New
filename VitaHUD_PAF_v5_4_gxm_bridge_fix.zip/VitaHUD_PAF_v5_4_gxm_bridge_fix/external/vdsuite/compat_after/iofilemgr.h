#pragma once
/* include_next compatibility bridge. */
#include <psp2/io/fcntl.h>
#include <psp2/io/stat.h>
