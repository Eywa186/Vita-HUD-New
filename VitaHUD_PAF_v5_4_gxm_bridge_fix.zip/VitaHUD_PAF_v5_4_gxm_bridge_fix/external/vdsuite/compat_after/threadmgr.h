#pragma once
/* include_next compatibility bridge. */
#include <psp2/kernel/threadmgr.h>
