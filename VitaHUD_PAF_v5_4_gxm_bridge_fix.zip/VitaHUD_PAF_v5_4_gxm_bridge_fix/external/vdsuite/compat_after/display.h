#pragma once
/* include_next compatibility bridge. */
#include <psp2/display.h>
