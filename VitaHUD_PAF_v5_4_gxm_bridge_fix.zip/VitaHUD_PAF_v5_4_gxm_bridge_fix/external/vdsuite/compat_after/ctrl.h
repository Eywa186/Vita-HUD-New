#pragma once
/* include_next compatibility bridge. */
#include <psp2/ctrl.h>
