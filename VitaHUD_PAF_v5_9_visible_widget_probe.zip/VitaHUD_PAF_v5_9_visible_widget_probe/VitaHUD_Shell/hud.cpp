#include "hud.h"
#include "profile.h"

namespace vitahud
{
    using namespace paf;

    /*
     * v5.9 visible widget probe:
     *
     * First real VDSuite visual attempt.
     *
     * No RCO.
     * No template.
     * No menu page.
     *
     * Goal:
     *   Get the framework root widget and attach one Text widget:
     *
     *     VITAHUD VDSUITE TEST
     */
    static paf::widget::Widget *s_hudRoot = SCE_NULL;
    static paf::widget::Text *s_hudText = SCE_NULL;

    static SceUInt64 s_lastCacheTick = 0;
    static char s_cachedLine[128] = "VITAHUD VDSUITE TEST";

    static int AppendText(char *out, int pos, const char *text)
    {
        while (*text && pos < 126) {
            out[pos++] = *text++;
        }

        out[pos] = 0;
        return pos;
    }

    static int AppendInt(char *out, int pos, int value)
    {
        char tmp[16];
        int n = 0;
        int i;

        if (value < 0 && pos < 126) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return pos;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (i = n - 1; i >= 0 && pos < 126; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
        return pos;
    }

    static void BuildTime(char *out, int *pos)
    {
        SceDateTime dt;
        sceRtcGetCurrentClockLocalTime(&dt);

        int hour = dt.hour;
        int minute = dt.minute;

        if (*pos + 5 >= 127) {
            return;
        }

        out[(*pos)++] = '0' + ((hour / 10) % 10);
        out[(*pos)++] = '0' + (hour % 10);
        out[(*pos)++] = ':';
        out[(*pos)++] = '0' + ((minute / 10) % 10);
        out[(*pos)++] = '0' + (minute % 10);
        out[*pos] = 0;
    }

    static void ToSceWChar16(const char *src, SceWChar16 *dst, int maxChars)
    {
        int i = 0;

        while (src[i] && i < maxChars - 1) {
            dst[i] = (SceWChar16)(unsigned char)src[i];
            i++;
        }

        dst[i] = 0;
    }

    void Hud::Create()
    {
        if (s_hudText) {
            return;
        }

        /*
         * Real VDSuite path:
         * Use framework root widget as parent.
         */
        paf::Framework *fw = paf::Framework::GetInstance();
        if (!fw) {
            return;
        }

        s_hudRoot = fw->GetRootWidget();
        if (!s_hudRoot) {
            return;
        }

        /*
         * Constructor is exported by ScePafWidget.
         * If this compiles/links but does not show, next step is RCO/template path.
         */
        s_hudText = new paf::widget::Text(s_hudRoot, 0);
        if (!s_hudText) {
            return;
        }

        SetPosition(g_settings.hudPosition);

        /*
         * Make it readable but small.
         * Params copied from VDSuite declaration defaults.
         */
        s_hudText->SetFontSize(22.0f, 0, 0, 0);

        UpdateCachedText();
        ApplyText();
    }

    void Hud::Destroy()
    {
        /*
         * Do not delete the widget yet in the probe.
         * Some PAF widgets are owned by the framework parent once attached.
         */
        s_hudText = SCE_NULL;
        s_hudRoot = SCE_NULL;
    }

    void Hud::SetVisible(bool visible)
    {
        /*
         * No Show/Hide wrapper exposed in these VDSuite headers.
         * For this probe, visibility means "do/don't update".
         */
        (void)visible;
    }

    void Hud::SetPosition(int position)
    {
        if (!s_hudText) {
            return;
        }

        SceFVector4 pos;

        pos.x = 20.0f;
        pos.y = 20.0f;
        pos.z = 0.0f;
        pos.w = 0.0f;

        switch (position) {
        case HUD_POS_TOP_LEFT:
            pos.x = 20.0f;
            pos.y = 20.0f;
            break;

        case HUD_POS_TOP_RIGHT:
            pos.x = 620.0f;
            pos.y = 20.0f;
            break;

        case HUD_POS_BOTTOM_LEFT:
            pos.x = 20.0f;
            pos.y = 500.0f;
            break;

        case HUD_POS_BOTTOM_RIGHT:
        default:
            pos.x = 620.0f;
            pos.y = 500.0f;
            break;
        }

        s_hudText->SetPosition(&pos);
    }

    void Hud::UpdateCachedText()
    {
        SceRtcTick tick;
        sceRtcGetCurrentTick(&tick);

        if (s_lastCacheTick != 0 && tick.tick - s_lastCacheTick < 500000) {
            return;
        }

        s_lastCacheTick = tick.tick;

        int battery = scePowerGetBatteryLifePercent();

        char line[128];
        int pos = 0;

        pos = AppendText(line, pos, "VITAHUD VDSUITE TEST  ");

        if (g_settings.showBattery) {
            pos = AppendText(line, pos, "BAT ");
            pos = AppendInt(line, pos, battery);
            pos = AppendText(line, pos, "%  ");
        }

        if (g_settings.showTime) {
            BuildTime(line, &pos);
        }

        for (int i = 0; i < 128; i++) {
            s_cachedLine[i] = line[i];

            if (line[i] == 0) {
                break;
            }
        }
    }

    void Hud::ApplyText()
    {
        if (!s_hudText) {
            return;
        }

        SceWChar16 wbuf[128];
        ToSceWChar16(s_cachedLine, wbuf, 128);

        paf::WString wtext(wbuf);
        s_hudText->SetLabel(&wtext);
    }

    void Hud::Update(void *arg)
    {
        (void)arg;

        if (!g_settings.hudEnabled) {
            return;
        }

        /*
         * If framework/root was not ready during module_start, keep trying.
         */
        if (!s_hudText) {
            Create();
        }

        UpdateCachedText();
        ApplyText();
    }
}
