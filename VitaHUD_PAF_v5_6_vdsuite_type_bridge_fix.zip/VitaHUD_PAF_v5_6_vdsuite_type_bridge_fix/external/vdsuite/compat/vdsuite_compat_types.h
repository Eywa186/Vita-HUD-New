#pragma once
/*
 * VitaHUD / VDSuite compatibility type bridge.
 *
 * VDSuite PAF headers were written against a slightly different SDK layout.
 * VitaSDK has some equivalent types under different names/headers.
 */

#include <psp2/types.h>
#include <psp2/io/fcntl.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
#include <psp2/kernel/sysmem.h>

#ifndef SCE_UID_INVALID_UID
#define SCE_UID_INVALID_UID (-1)
#endif

#ifndef SCE_KERNEL_START_SUCCESS
#define SCE_KERNEL_START_SUCCESS 0
#endif

#ifndef SCE_KERNEL_STOP_SUCCESS
#define SCE_KERNEL_STOP_SUCCESS 0
#endif

/*
 * VDSuite expects SceIoMode. VitaSDK commonly exposes SceMode.
 */
typedef SceMode SceIoMode;

/*
 * Minimal async I/O param bridge.
 * VDSuite only needs the type visible at compile time here.
 */
typedef struct SceIoAsyncParam {
    SceUInt32 size;
    SceUInt32 unk[7];
} SceIoAsyncParam;

/*
 * Minimal SHA1 context bridge for paf/misc.h.
 */
typedef struct SceSha1Context {
    SceUInt32 h[5];
    SceUInt32 count[2];
    SceUChar buffer[64];
} SceSha1Context;
