#include "hud.h"
#include "profile.h"

namespace vitahud
{
    using namespace paf;

    /*
     * v6.0 main-thread widget probe:
     *
     * v5.9 built but did not show.
     * Likely reason: widget creation happened outside PAF/main UI thread.
     *
     * This version schedules create/update through:
     *   paf::common::MainThreadCallList::Register(...)
     *
     * If this still does not show, the next step is true RCO/template injection.
     */
    static paf::widget::Widget *s_hudRoot = SCE_NULL;
    static paf::widget::Text *s_hudText = SCE_NULL;

    static volatile int s_createQueued = 0;
    static volatile int s_updateQueued = 0;

    static SceUInt64 s_lastCacheTick = 0;
    static char s_cachedLine[128] = "VITAHUD MAIN THREAD TEST";

    static int AppendText(char *out, int pos, const char *text)
    {
        while (*text && pos < 126) {
            out[pos++] = *text++;
        }

        out[pos] = 0;
        return pos;
    }

    static int AppendInt(char *out, int pos, int value)
    {
        char tmp[16];
        int n = 0;
        int i;

        if (value < 0 && pos < 126) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return pos;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (i = n - 1; i >= 0 && pos < 126; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
        return pos;
    }

    static void BuildTime(char *out, int *pos)
    {
        SceDateTime dt;
        sceRtcGetCurrentClockLocalTime(&dt);

        int hour = dt.hour;
        int minute = dt.minute;

        if (*pos + 5 >= 127) {
            return;
        }

        out[(*pos)++] = '0' + ((hour / 10) % 10);
        out[(*pos)++] = '0' + (hour % 10);
        out[(*pos)++] = ':';
        out[(*pos)++] = '0' + ((minute / 10) % 10);
        out[(*pos)++] = '0' + (minute % 10);
        out[*pos] = 0;
    }

    static void ToSceWChar16(const char *src, SceWChar16 *dst, int maxChars)
    {
        int i = 0;

        while (src[i] && i < maxChars - 1) {
            dst[i] = (SceWChar16)(unsigned char)src[i];
            i++;
        }

        dst[i] = 0;
    }

    static void ApplyTextOnMainThread(void *arg)
    {
        (void)arg;

        s_updateQueued = 0;

        if (!s_hudText) {
            return;
        }

        SceWChar16 wbuf[128];
        ToSceWChar16(s_cachedLine, wbuf, 128);

        paf::WString wtext(wbuf);
        s_hudText->SetLabel(&wtext);
    }

    static void CreateOnMainThread(void *arg)
    {
        (void)arg;

        s_createQueued = 0;

        if (s_hudText) {
            return;
        }

        paf::Framework *fw = paf::Framework::GetInstance();
        if (!fw) {
            return;
        }

        s_hudRoot = fw->GetRootWidget();
        if (!s_hudRoot) {
            return;
        }

        s_hudText = new paf::widget::Text(s_hudRoot, 0);
        if (!s_hudText) {
            return;
        }

        /*
         * Try to force normal visible geometry.
         */
        SceFVector4 pos;
        pos.x = 30.0f;
        pos.y = 30.0f;
        pos.z = 0.0f;
        pos.w = 0.0f;

        SceFVector4 size;
        size.x = 600.0f;
        size.y = 50.0f;
        size.z = 0.0f;
        size.w = 0.0f;

        s_hudText->SetPosition(&pos);
        s_hudText->SetSize(&size);
        s_hudText->SetFontSize(24.0f, 0, 0, 0);

        ApplyTextOnMainThread(SCE_NULL);
    }

    static void QueueCreate()
    {
        if (s_hudText || s_createQueued) {
            return;
        }

        s_createQueued = 1;
        paf::common::MainThreadCallList::Register(CreateOnMainThread, SCE_NULL);
    }

    static void QueueUpdate()
    {
        if (!s_hudText || s_updateQueued) {
            return;
        }

        s_updateQueued = 1;
        paf::common::MainThreadCallList::Register(ApplyTextOnMainThread, SCE_NULL);
    }

    void Hud::Create()
    {
        QueueCreate();
    }

    void Hud::Destroy()
    {
        s_hudText = SCE_NULL;
        s_hudRoot = SCE_NULL;
        s_createQueued = 0;
        s_updateQueued = 0;
    }

    void Hud::SetVisible(bool visible)
    {
        (void)visible;
    }

    void Hud::SetPosition(int position)
    {
        (void)position;

        if (!s_hudText) {
            return;
        }

        /*
         * Keep fixed top-left for this probe so it is easy to spot.
         */
        SceFVector4 pos;
        pos.x = 30.0f;
        pos.y = 30.0f;
        pos.z = 0.0f;
        pos.w = 0.0f;

        s_hudText->SetPosition(&pos);
    }

    void Hud::UpdateCachedText()
    {
        SceRtcTick tick;
        sceRtcGetCurrentTick(&tick);

        if (s_lastCacheTick != 0 && tick.tick - s_lastCacheTick < 500000) {
            return;
        }

        s_lastCacheTick = tick.tick;

        int battery = scePowerGetBatteryLifePercent();

        char line[128];
        int pos = 0;

        pos = AppendText(line, pos, "VITAHUD MAIN THREAD TEST  ");

        if (g_settings.showBattery) {
            pos = AppendText(line, pos, "BAT ");
            pos = AppendInt(line, pos, battery);
            pos = AppendText(line, pos, "%  ");
        }

        if (g_settings.showTime) {
            BuildTime(line, &pos);
        }

        for (int i = 0; i < 128; i++) {
            s_cachedLine[i] = line[i];

            if (line[i] == 0) {
                break;
            }
        }
    }

    void Hud::ApplyText()
    {
        QueueUpdate();
    }

    void Hud::Update(void *arg)
    {
        (void)arg;

        if (!g_settings.hudEnabled) {
            return;
        }

        if (!s_hudText) {
            QueueCreate();
            return;
        }

        UpdateCachedText();
        ApplyText();
    }
}
