#pragma once

namespace vitahud
{
    namespace DebugOverlay
    {
        void Update();
    }
}
