#pragma once

namespace vitahud
{
    namespace DebugLog
    {
        void Init();
        void Write(const char *text);
        void WriteInt(const char *label, int value);
    }
}
