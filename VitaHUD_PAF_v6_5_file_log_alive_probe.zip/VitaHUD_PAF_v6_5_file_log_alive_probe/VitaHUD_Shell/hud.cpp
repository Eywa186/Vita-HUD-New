#include "hud.h"
#include "profile.h"
#include "rco_ids.h"

namespace vitahud
{
    using namespace paf;

    /*
     * v6.3 sample RCO page probe.
     *
     * Uses the real vitasdk-paf-component text sample RCO:
     *   sample_plugin.rco
     *
     * Expected XML:
     *   resource id="sample_plugin"
     *   page id="page_main"
     *   text id="test_strings_id"
     */

    static paf::Plugin *s_plugin = SCE_NULL;
    static paf::widget::Widget *s_root = SCE_NULL;
    static paf::widget::Text *s_text = SCE_NULL;

    static volatile int s_loadStarted = 0;
    static volatile int s_loadFinished = 0;

    static SceUInt64 s_lastCacheTick = 0;
    static char s_cachedLine[128] = "VITAHUD SAMPLE RCO";

    static int AppendText(char *out, int pos, const char *text)
    {
        while (*text && pos < 126) {
            out[pos++] = *text++;
        }

        out[pos] = 0;
        return pos;
    }

    static int AppendInt(char *out, int pos, int value)
    {
        char tmp[16];
        int n = 0;
        int i;

        if (value < 0 && pos < 126) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return pos;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (i = n - 1; i >= 0 && pos < 126; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
        return pos;
    }

    static void BuildTime(char *out, int *pos)
    {
        SceDateTime dt;
        sceRtcGetCurrentClockLocalTime(&dt);

        int hour = dt.hour;
        int minute = dt.minute;

        if (*pos + 5 >= 127) {
            return;
        }

        out[(*pos)++] = '0' + ((hour / 10) % 10);
        out[(*pos)++] = '0' + (hour % 10);
        out[(*pos)++] = ':';
        out[(*pos)++] = '0' + ((minute / 10) % 10);
        out[(*pos)++] = '0' + (minute % 10);
        out[*pos] = 0;
    }

    static void ToSceWChar16(const char *src, SceWChar16 *dst, int maxChars)
    {
        int i = 0;

        while (src[i] && i < maxChars - 1) {
            dst[i] = (SceWChar16)(unsigned char)src[i];
            i++;
        }

        dst[i] = 0;
    }

    static paf::Resource::Element MakeElementById(const char *id)
    {
        paf::Resource::Element e;
        e.id.Set(id);
        e.hash = e.GetHashById(&e);
        return e;
    }

    static void ApplyTextInternal()
    {
        if (!s_text) {
            return;
        }

        SceWChar16 wbuf[128];
        ToSceWChar16(s_cachedLine, wbuf, 128);

        paf::WString wtext(wbuf);
        s_text->SetLabel(&wtext);
    }

    static void BuildWidgets()
    {
        if (!s_plugin || s_text) {
            return;
        }

        paf::Plugin::RootWidgetInitParam rootParam;

        paf::Resource::Element pageInfo = MakeElementById(VITAHUD_PAGE_ID);
        paf::Resource::Element textInfo = MakeElementById(VITAHUD_TEXT_ID);

        s_root = s_plugin->SetRootWidget(&pageInfo, &rootParam);

        if (!s_root) {
            return;
        }

        paf::widget::Widget *found = s_root->GetChildByHash(&textInfo, 0);
        if (!found) {
            found = s_root->GetChildByHash(&textInfo, 1);
        }
        if (!found) {
            found = s_root->GetChildByHash(&textInfo, 2);
        }

        s_text = (paf::widget::Text *)found;

        if (!s_text) {
            return;
        }

        /*
         * Move text to a clear top-left test position and enlarge it.
         */
        SceFVector4 pos;
        pos.x = 30.0f;
        pos.y = 30.0f;
        pos.z = 0.0f;
        pos.w = 0.0f;

        SceFVector4 size;
        size.x = 900.0f;
        size.y = 60.0f;
        size.z = 0.0f;
        size.w = 0.0f;

        s_text->SetPosition(&pos);
        s_text->SetSize(&size);
        s_text->SetFontSize(28.0f, 0, 0, 0);

        ApplyTextInternal();
    }

    static void PluginLoadCallback(paf::Plugin *plugin)
    {
        s_plugin = plugin;
        s_loadFinished = 1;

        BuildWidgets();
    }

    static void StartPluginLoad()
    {
        if (s_loadStarted) {
            return;
        }

        s_loadStarted = 1;

        paf::Framework::PluginInitParam initParam;

        initParam.pluginName.Set(VITAHUD_RCO_PLUGIN_NAME);
        initParam.scopeName.Set("__main__");
        initParam.resourcePath.Set(VITAHUD_RCO_PATH);
        initParam.pluginPath.Set("");

        initParam.loadCB1 = PluginLoadCallback;
        initParam.loadCB2 = SCE_NULL;
        initParam.loadCB3 = SCE_NULL;
        initParam.unloadCB1 = SCE_NULL;
        initParam.unloadCB2 = SCE_NULL;

        paf::Framework::LoadPlugin(&initParam, PluginLoadCallback, SCE_NULL);
    }

    void Hud::Create()
    {
        StartPluginLoad();
    }

    void Hud::Destroy()
    {
        s_text = SCE_NULL;
        s_root = SCE_NULL;
        s_plugin = SCE_NULL;
        s_loadStarted = 0;
        s_loadFinished = 0;
    }

    void Hud::SetVisible(bool visible)
    {
        (void)visible;
    }

    void Hud::SetPosition(int position)
    {
        (void)position;

        if (!s_text) {
            return;
        }

        SceFVector4 pos;
        pos.x = 30.0f;
        pos.y = 30.0f;
        pos.z = 0.0f;
        pos.w = 0.0f;

        s_text->SetPosition(&pos);
    }

    void Hud::UpdateCachedText()
    {
        SceRtcTick tick;
        sceRtcGetCurrentTick(&tick);

        if (s_lastCacheTick != 0 && tick.tick - s_lastCacheTick < 500000) {
            return;
        }

        s_lastCacheTick = tick.tick;

        int battery = scePowerGetBatteryLifePercent();

        char line[128];
        int pos = 0;

        pos = AppendText(line, pos, "VITAHUD SAMPLE RCO  ");

        if (!s_loadFinished) {
            pos = AppendText(line, pos, "LOADING  ");
        }

        if (g_settings.showBattery) {
            pos = AppendText(line, pos, "BAT ");
            pos = AppendInt(line, pos, battery);
            pos = AppendText(line, pos, "%  ");
        }

        if (g_settings.showTime) {
            BuildTime(line, &pos);
        }

        for (int i = 0; i < 128; i++) {
            s_cachedLine[i] = line[i];

            if (line[i] == 0) {
                break;
            }
        }
    }

    void Hud::ApplyText()
    {
        ApplyTextInternal();
    }

    void Hud::Update(void *arg)
    {
        (void)arg;

        if (!g_settings.hudEnabled) {
            return;
        }

        if (!s_loadStarted) {
            StartPluginLoad();
        }

        if (s_plugin && !s_text) {
            BuildWidgets();
        }

        UpdateCachedText();
        ApplyText();
    }
}
