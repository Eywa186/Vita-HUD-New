#include <psp2/display.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/types.h>

#include "debug_overlay.h"

namespace vitahud
{
namespace DebugOverlay
{
    static int s_frameCounter = 0;

    static const unsigned char FONT_UNKNOWN[7] = {
        0x1F, 0x11, 0x02, 0x04, 0x04, 0x00, 0x04
    };

    static const unsigned char *Glyph(char c)
    {
        static const unsigned char A[7] = {0x0E,0x11,0x11,0x1F,0x11,0x11,0x11};
        static const unsigned char D[7] = {0x1E,0x11,0x11,0x11,0x11,0x11,0x1E};
        static const unsigned char E[7] = {0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F};
        static const unsigned char G[7] = {0x0F,0x10,0x10,0x13,0x11,0x11,0x0F};
        static const unsigned char H[7] = {0x11,0x11,0x11,0x1F,0x11,0x11,0x11};
        static const unsigned char I[7] = {0x1F,0x04,0x04,0x04,0x04,0x04,0x1F};
        static const unsigned char L[7] = {0x10,0x10,0x10,0x10,0x10,0x10,0x1F};
        static const unsigned char N[7] = {0x11,0x19,0x15,0x13,0x11,0x11,0x11};
        static const unsigned char P[7] = {0x1E,0x11,0x11,0x1E,0x10,0x10,0x10};
        static const unsigned char T[7] = {0x1F,0x04,0x04,0x04,0x04,0x04,0x04};
        static const unsigned char U[7] = {0x11,0x11,0x11,0x11,0x11,0x11,0x0E};
        static const unsigned char V[7] = {0x11,0x11,0x11,0x11,0x11,0x0A,0x04};
        static const unsigned char SPACE[7] = {0,0,0,0,0,0,0};
        static const unsigned char ZERO[7] = {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E};
        static const unsigned char ONE[7] = {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E};
        static const unsigned char TWO[7] = {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F};
        static const unsigned char THREE[7] = {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E};
        static const unsigned char FOUR[7] = {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02};
        static const unsigned char FIVE[7] = {0x1F,0x10,0x10,0x1E,0x01,0x01,0x1E};
        static const unsigned char SIX[7] = {0x0E,0x10,0x10,0x1E,0x11,0x11,0x0E};
        static const unsigned char SEVEN[7] = {0x1F,0x01,0x02,0x04,0x08,0x08,0x08};
        static const unsigned char EIGHT[7] = {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E};
        static const unsigned char NINE[7] = {0x0E,0x11,0x11,0x0F,0x01,0x01,0x0E};

        switch (c) {
        case 'A': return A;
        case 'D': return D;
        case 'E': return E;
        case 'G': return G;
        case 'H': return H;
        case 'I': return I;
        case 'L': return L;
        case 'N': return N;
        case 'P': return P;
        case 'T': return T;
        case 'U': return U;
        case 'V': return V;
        case ' ': return SPACE;
        case '0': return ZERO;
        case '1': return ONE;
        case '2': return TWO;
        case '3': return THREE;
        case '4': return FOUR;
        case '5': return FIVE;
        case '6': return SIX;
        case '7': return SEVEN;
        case '8': return EIGHT;
        case '9': return NINE;
        default: return FONT_UNKNOWN;
        }
    }

    static void PutPixel(SceDisplayFrameBuf *fb, int x, int y, unsigned int color)
    {
        if (!fb || !fb->base) {
            return;
        }

        if (x < 0 || y < 0 || x >= (int)fb->width || y >= (int)fb->height) {
            return;
        }

        unsigned int *pixels = (unsigned int *)fb->base;
        pixels[(y * fb->pitch) + x] = color;
    }

    static void FillRect(SceDisplayFrameBuf *fb, int x, int y, int w, int h, unsigned int color)
    {
        for (int yy = 0; yy < h; yy++) {
            for (int xx = 0; xx < w; xx++) {
                PutPixel(fb, x + xx, y + yy, color);
            }
        }
    }

    static void DrawChar(SceDisplayFrameBuf *fb, int x, int y, char c, int scale, unsigned int color)
    {
        const unsigned char *g = Glyph(c);

        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (g[row] & (1 << (4 - col))) {
                    FillRect(fb, x + col * scale, y + row * scale, scale, scale, color);
                }
            }
        }
    }

    static void DrawText(SceDisplayFrameBuf *fb, int x, int y, const char *text, int scale, unsigned int color)
    {
        int cursor = x;

        while (*text) {
            DrawChar(fb, cursor, y, *text, scale, color);
            cursor += 6 * scale;
            text++;
        }
    }

    void Update()
    {
        s_frameCounter++;

        SceDisplayFrameBuf fb;
        fb.size = sizeof(SceDisplayFrameBuf);
        fb.base = 0;
        fb.pitch = 0;
        fb.pixelformat = 0;
        fb.width = 0;
        fb.height = 0;

        int ret = sceDisplayGetFrameBuf(&fb, SCE_DISPLAY_SETBUF_NEXTFRAME);
        if (ret < 0 || !fb.base) {
            return;
        }

        /*
         * Black backing box + bright text.
         * This only proves plugin/thread/framebuffer path is alive.
         */
        FillRect(&fb, 10, 10, 455, 32, 0xFF000000);
        DrawText(&fb, 18, 17, "VITAHUD PLUGIN ALIVE", 3, 0xFFFFFFFF);

        /*
         * Tiny frame counter so we know it is updating, not just stale.
         */
        char buf[16];
        int n = s_frameCounter % 1000;
        buf[0] = '0' + ((n / 100) % 10);
        buf[1] = '0' + ((n / 10) % 10);
        buf[2] = '0' + (n % 10);
        buf[3] = 0;

        DrawText(&fb, 18, 52, buf, 2, 0xFFFFFFFF);
    }
}
}
