#include <psp2/io/fcntl.h>
#include <psp2/io/stat.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/types.h>

#include "debug_log.h"

namespace vitahud
{
namespace DebugLog
{
    static void WriteRaw(const char *text)
    {
        SceUID fd = sceIoOpen("ur0:data/VitaHUD/vitahud_alive.txt",
                              SCE_O_WRONLY | SCE_O_CREAT | SCE_O_APPEND,
                              0777);

        if (fd < 0) {
            return;
        }

        const char *p = text;
        int len = 0;

        while (p && p[len]) {
            len++;
        }

        if (len > 0) {
            sceIoWrite(fd, text, len);
        }

        sceIoClose(fd);
    }

    static void IntToText(int value, char *out)
    {
        char tmp[16];
        int pos = 0;
        int n = 0;

        if (value < 0) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (int i = n - 1; i >= 0; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
    }

    void Init()
    {
        sceIoMkdir("ur0:data/VitaHUD", 0777);

        SceUID fd = sceIoOpen("ur0:data/VitaHUD/vitahud_alive.txt",
                              SCE_O_WRONLY | SCE_O_CREAT | SCE_O_TRUNC,
                              0777);

        if (fd >= 0) {
            const char *msg =
                "VitaHUD v6.5 module_start reached\n"
                "If you can read this file, the SUPRX loaded.\n";
            sceIoWrite(fd, msg, 78);
            sceIoClose(fd);
        }
    }

    void Write(const char *text)
    {
        WriteRaw(text);
        WriteRaw("\n");
    }

    void WriteInt(const char *label, int value)
    {
        char number[32];
        IntToText(value, number);

        WriteRaw(label);
        WriteRaw(": ");
        WriteRaw(number);
        WriteRaw("\n");
    }
}
}
