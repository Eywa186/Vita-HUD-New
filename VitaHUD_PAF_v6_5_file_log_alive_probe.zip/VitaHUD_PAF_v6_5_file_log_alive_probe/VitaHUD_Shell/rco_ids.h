#pragma once

/*
 * v6.3 real sample RCO probe.
 *
 * Source:
 * vitasdk-paf-component / paf_sample_cxml_text
 *
 * RCO:
 *   sample_plugin.rco
 *
 * IDs from sample_plugin.xml:
 *   resource id: sample_plugin
 *   page id:     page_main
 *   text id:     test_strings_id
 */
#define VITAHUD_RCO_PLUGIN_NAME "sample_plugin"
#define VITAHUD_RCO_PATH        "ur0:data/VitaHUD/sample_plugin.rco"
#define VITAHUD_PAGE_ID         "page_main"
#define VITAHUD_TEXT_ID         "test_strings_id"
