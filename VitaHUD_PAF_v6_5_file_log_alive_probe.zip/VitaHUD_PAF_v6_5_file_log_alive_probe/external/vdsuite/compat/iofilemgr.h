#pragma once
#include "vdsuite_compat_types.h"
