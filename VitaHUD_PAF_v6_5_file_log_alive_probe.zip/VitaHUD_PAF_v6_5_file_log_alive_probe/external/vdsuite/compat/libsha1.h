#pragma once
#include "vdsuite_compat_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef SceSha1Context SHA1Context;

static inline void SHA1Reset(SHA1Context *context) {
    (void)context;
}

static inline int SHA1Result(SHA1Context *context, unsigned char Message_Digest[20]) {
    (void)context;
    if (Message_Digest) {
        for (int i = 0; i < 20; i++) {
            Message_Digest[i] = 0;
        }
    }
    return 1;
}

static inline void SHA1Input(SHA1Context *context, const unsigned char *message_array, unsigned length) {
    (void)context;
    (void)message_array;
    (void)length;
}

#ifdef __cplusplus
}
#endif
