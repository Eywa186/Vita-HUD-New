#pragma once
/*
 * VitaHUD / VDSuite compatibility type bridge.
 *
 * VDSuite PAF headers were written against a slightly different SDK layout.
 * VitaSDK already provides some of these types, so avoid redefining them.
 */

#include <psp2/types.h>
#include <psp2/io/fcntl.h>
#include <psp2/io/dirent.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
#include <psp2/kernel/sysmem.h>

#ifndef SCE_UID_INVALID_UID
#define SCE_UID_INVALID_UID (-1)
#endif

#ifndef SCE_KERNEL_START_SUCCESS
#define SCE_KERNEL_START_SUCCESS 0
#endif

#ifndef SCE_KERNEL_STOP_SUCCESS
#define SCE_KERNEL_STOP_SUCCESS 0
#endif

/*
 * Do NOT typedef SceIoMode.
 * VitaSDK already defines it in psp2common/kernel/iofilemgr.h.
 */

/*
 * Minimal async I/O param bridge.
 * VDSuite only needs the type visible at compile time here.
 */
#ifndef VITAHUD_HAS_SCE_IO_ASYNC_PARAM
#define VITAHUD_HAS_SCE_IO_ASYNC_PARAM
typedef struct SceIoAsyncParam {
    SceUInt32 size;
    SceUInt32 unk[7];
} SceIoAsyncParam;
#endif

/*
 * Minimal SHA1 context bridge for paf/misc.h.
 */
#ifndef VITAHUD_HAS_SCE_SHA1_CONTEXT
#define VITAHUD_HAS_SCE_SHA1_CONTEXT
typedef struct SceSha1Context {
    SceUInt32 h[5];
    SceUInt32 count[2];
    SceUChar8 buffer[64];
} SceSha1Context;
#endif
