#pragma once
#include "vdsuite_compat_types.h"

#ifndef SCE_NULL
#define SCE_NULL 0
#endif
