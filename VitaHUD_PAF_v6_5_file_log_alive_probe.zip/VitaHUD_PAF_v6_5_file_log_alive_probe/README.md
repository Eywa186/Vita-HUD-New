# VitaHUD PAF v5 — VDSuite Real PAF Probe

This package bundles the VDSuite files you uploaded.

## Confirmed inside VDSuite

```txt
sdk/target/include/vdsuite/user/paf.h
sdk/target/include/vdsuite/user/paf/*
sdk/target/lib/vdsuite/libScePaf*_stub_weak.a
```

## What v5 does

- Bundles VDSuite under:

```txt
external/vdsuite/sdk/
```

- Adds compatibility bridge headers for old VDSuite shorthand includes:

```txt
external/vdsuite/compat/kernel.h
external/vdsuite/compat/scetypes.h
```

- CMake now includes:

```txt
external/vdsuite/sdk/target/include/vdsuite/user
external/vdsuite/sdk/target/include/vdsuite/common
external/vdsuite/sdk/target/lib/vdsuite
```

- Links the PAF stubs matching PSVshellPlus style:

```txt
ScePafToplevel_stub_weak
ScePafStdc_stub_weak
ScePafCommon_stub_weak
ScePafWidget_stub_weak
ScePafThread_stub_weak
ScePafResource_stub_weak
ScePafGraphics_stub_weak
ScePafMisc_stub_weak
```

## Important

This is a real VDSuite probe.

If it fails, that is good data: the next error will tell us exactly which API names need to be adapted.

The likely next issue is that VDSuite PAF uses `paf::widget::*`, while the PSVshellPlus code style uses `paf::ui::*`.


## v5.1

Fixed VDSuite shorthand include bridge:

```txt
external/vdsuite/compat/ctrl.h
```

This maps:

```cpp
#include_next <ctrl.h>
```

to:

```cpp
#include <psp2/ctrl.h>
```

Also added likely bridge headers for display, power, rtc, appmgr, iofilemgr, threadmgr, and modulemgr.


## v5.2

Fixed `#include_next <ctrl.h>` behavior.

VDSuite `common/ctrl.h` uses:

```cpp
#include_next <ctrl.h>
```

So the compatibility bridge must appear **after** the VDSuite common include path.

Added:

```txt
external/vdsuite/compat_after/
```

CMake include order is now:

```txt
compat
vdsuite/user
vdsuite/common
compat_after
```


## v5.3

Fixed `kernel.h` bridge.

Removed invalid include:

```cpp
#include <psp2/kernel/types.h>
```

Replaced with:

```cpp
#include <psp2/types.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/modulemgr.h>
```


## v5.4

Fixed missing VDSuite graphics shorthand header:

```txt
gxm.h
```

Added bridge:

```cpp
#include <psp2/gxm.h>
```

in:

```txt
external/vdsuite/compat/gxm.h
external/vdsuite/compat_after/gxm.h
```


## v5.5

Fixed missing VDSuite dependency:

```txt
libsha1.h
```

The VDSuite package does not include `libsha1.h`, but `paf/misc.h` includes it.

Added minimal compile bridge:

```txt
external/vdsuite/compat/libsha1.h
external/vdsuite/compat_after/libsha1.h
```


## v5.6

Fixed missing VDSuite/VitaSDK type aliases exposed by real PAF headers:

```txt
SceIoMode
SceIoAsyncParam
SCE_UID_INVALID_UID
SceSha1Context
SceKernelAllocMemBlockOpt
SceKernelMemBlockType
```

Added:

```txt
external/vdsuite/compat/vdsuite_compat_types.h
external/vdsuite/compat_after/vdsuite_compat_types.h
```

CMake now force-includes the compatibility type bridge before compiling.


## v5.7

Fixed compatibility bridge mistakes:

- Removed conflicting `typedef SceMode SceIoMode;`
- Changed `SceUChar` to `SceUChar8` in `SceSha1Context`

VitaSDK already defines `SceIoMode`, so the bridge no longer redefines it.


## v5.8

Aligned source with real VDSuite API names.

Removed fake compatibility API usage:

```txt
paf::ui::*
Plugin::PageOpen()
Plugin::TemplateOpen()
Plugin::PageClose()
paf::math::v4
paf::wstring
```

Replaced with real-header compile-safe names:

```txt
paf::widget::Widget
paf::widget::Text
paf::WString later
```

This version is a real VDSuite compile probe. It does not draw the page yet.
Next phase after successful compile: wire real `Plugin::SetRootWidget`,
`AddWidgetFromTemplate`, `GetChildByHash`, and real resource hashes.


## v5.9 Visible Widget Probe

First real visual attempt using real VDSuite API:

```cpp
paf::Framework::GetInstance()
fw->GetRootWidget()
new paf::widget::Text(root, 0)
paf::WString
Text::SetLabel(...)
Widget::SetPosition(...)
Widget::SetFontSize(...)
```

Target on screen:

```txt
VITAHUD VDSUITE TEST
```

This does not use RCO/templates yet. It tests whether a direct Text widget can attach to the framework root.
If this builds but does not show, next step is the RCO/template path.


## v6.0 Main-Thread Widget Probe

v5.9 built but did not show.

v6.0 tries creating/updating the text widget through:

```cpp
paf::common::MainThreadCallList::Register(...)
```

Target on screen:

```txt
VITAHUD MAIN THREAD TEST
```

Fixed top-left position:

```txt
x = 30
y = 30
```

If this builds but still does not show, direct widget creation is not enough and the next step is RCO/template injection.


## v6.1 RCO-Ready Compile Base

v6.0 failed because this VDSuite header package does not expose:

```cpp
paf::common::MainThreadCallList
```

v6.1 removes that dependency and returns to a clean real-VDSuite compile base.

Important result from testing:
- v5.9 direct widget creation built, but did not show on Vita.
- v6.0 main-thread path is unavailable in these headers.
- Next real visible path is RCO/template injection.

Next path:
```cpp
paf::Framework::LoadPlugin(...)
paf::Plugin::SetRootWidget(...)
paf::Plugin::AddWidgetFromTemplate(...)
paf::widget::Widget::GetChildByHash(...)
paf::widget::Text::SetLabel(...)
```


## v6.3 Sample RCO Page Probe

Uses real sample RCO from `vitasdk-paf-component`:

```txt
paf_sample_cxml_text/sample_plugin.rco
```

Expected install files:

```txt
ur0:tai/vitahud_paf_v5.suprx
ur0:data/VitaHUD/sample_plugin.rco
```

IDs from `sample_plugin.xml`:

```txt
resource/plugin id: sample_plugin
page id: page_main
text id: test_strings_id
```

Target text if visible:

```txt
VITAHUD SAMPLE RCO
```


## v6.4 Hybrid Alive Debug Probe

Purpose:
- Keep v6.3 RCO/sample plugin load attempt.
- Add direct framebuffer fallback so we can prove the SUPRX is loading/running.

Direct framebuffer target:

```txt
VITAHUD PLUGIN ALIVE
```

Position:

```txt
Top-left, black backing box.
```

Also draws a 000-999 frame counter underneath.

Important:
- If `VITAHUD PLUGIN ALIVE` appears, the plugin is loading and the input/update thread is alive.
- If RCO text still does not appear, the failure is isolated to PAF/RCO attachment.
- If nothing appears, the plugin is not loading from config, or direct framebuffer drawing is blocked in that shell state.


## v6.5 File-Log Alive Probe

Visual debug did not show. This version writes a file immediately in `module_start`.

Check after reboot:

```txt
ur0:data/VitaHUD/vitahud_alive.txt
```

If this file exists, the SUPRX is loading.

If this file does NOT exist, the plugin is not loading from config.txt, or the config path/location is wrong.

This separates plugin loading from PAF/RCO/framebuffer visibility.
