#pragma once
/*
 * Minimal libsha1.h bridge for VDSuite PAF headers.
 *
 * VDSuite paf/misc.h includes <libsha1.h>, but the vdsuite-libraries package
 * does not ship this header. We only need declarations/types to compile.
 */

#include <psp2/types.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SHA1Context {
    SceUInt32 state[5];
    SceUInt32 count[2];
    unsigned char buffer[64];
} SHA1Context;

static inline void SHA1Reset(SHA1Context *context) {
    (void)context;
}

static inline int SHA1Result(SHA1Context *context, unsigned char Message_Digest[20]) {
    (void)context;
    if (Message_Digest) {
        for (int i = 0; i < 20; i++) {
            Message_Digest[i] = 0;
        }
    }
    return 1;
}

static inline void SHA1Input(SHA1Context *context, const unsigned char *message_array, unsigned length) {
    (void)context;
    (void)message_array;
    (void)length;
}

#ifdef __cplusplus
}
#endif
