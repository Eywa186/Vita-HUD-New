#include "hud.h"
#include "profile.h"

namespace vitahud
{
    using namespace paf;

    /*
     * v5.8 real VDSuite API alignment:
     *
     * Real VDSuite headers expose:
     *   paf::widget::Widget
     *   paf::widget::Text
     *   paf::WString
     *
     * They do NOT expose the fake compatibility API:
     *   paf::ui::Text
     *   Plugin::PageOpen()
     *   Plugin::TemplateOpen()
     *
     * So this version intentionally compiles against the real VDSuite names
     * but does not attempt to open the visual page yet.
     */
    static paf::widget::Widget *s_hudRoot = SCE_NULL;
    static paf::widget::Text *s_hudText = SCE_NULL;

    static SceUInt64 s_lastCacheTick = 0;
    static char s_cachedLine[128] = "VITAHUD VDSUITE COMPILE TEST";

    static int AppendText(char *out, int pos, const char *text)
    {
        while (*text) {
            out[pos++] = *text++;
        }

        out[pos] = 0;
        return pos;
    }

    static int AppendInt(char *out, int pos, int value)
    {
        char tmp[16];
        int n = 0;
        int i;

        if (value < 0) {
            out[pos++] = '-';
            value = -value;
        }

        if (value == 0) {
            out[pos++] = '0';
            out[pos] = 0;
            return pos;
        }

        while (value > 0 && n < 15) {
            tmp[n++] = '0' + (value % 10);
            value /= 10;
        }

        for (i = n - 1; i >= 0; i--) {
            out[pos++] = tmp[i];
        }

        out[pos] = 0;
        return pos;
    }

    static void BuildTime(char *out, int *pos)
    {
        SceDateTime dt;
        sceRtcGetCurrentClockLocalTime(&dt);

        int hour = dt.hour;
        int minute = dt.minute;

        out[(*pos)++] = '0' + ((hour / 10) % 10);
        out[(*pos)++] = '0' + (hour % 10);
        out[(*pos)++] = ':';
        out[(*pos)++] = '0' + ((minute / 10) % 10);
        out[(*pos)++] = '0' + (minute % 10);
        out[*pos] = 0;
    }

    void Hud::Create()
    {
        /*
         * Real page opening is not wired in v5.8.
         *
         * Next phase must use real VDSuite calls:
         *   paf::Plugin::SetRootWidget(...)
         *   paf::Plugin::AddWidgetFromTemplate(...)
         *   paf::widget::Widget::GetChildByHash(...)
         *
         * For now, this validates that real VDSuite headers/libs compile.
         */
        s_hudRoot = SCE_NULL;
        s_hudText = SCE_NULL;
    }

    void Hud::Destroy()
    {
        s_hudRoot = SCE_NULL;
        s_hudText = SCE_NULL;
    }

    void Hud::SetVisible(bool visible)
    {
        (void)visible;

        /*
         * Real VDSuite transition call will be added after root widget creation.
         */
    }

    void Hud::SetPosition(int position)
    {
        (void)position;

        /*
         * Real VDSuite uses Widget::SetPosition(const SceFVector4*, ...).
         * Add after s_hudRoot is real.
         */
    }

    void Hud::UpdateCachedText()
    {
        SceRtcTick tick;
        sceRtcGetCurrentTick(&tick);

        if (s_lastCacheTick != 0 && tick.tick - s_lastCacheTick < 500000) {
            return;
        }

        s_lastCacheTick = tick.tick;

        int battery = scePowerGetBatteryLifePercent();

        char line[128];
        int pos = 0;

        pos = AppendText(line, pos, "VITAHUD VDSUITE TEST  ");

        if (g_settings.showBattery) {
            pos = AppendText(line, pos, "BAT ");
            pos = AppendInt(line, pos, battery);
            pos = AppendText(line, pos, "%  ");
        }

        if (g_settings.showTime) {
            BuildTime(line, &pos);
        }

        for (int i = 0; i < 128; i++) {
            s_cachedLine[i] = line[i];

            if (line[i] == 0) {
                break;
            }
        }
    }

    void Hud::ApplyText()
    {
        /*
         * No real text widget yet.
         * This function stays here so the later visual overlay path only needs
         * one change: assign s_hudText, then set string with real VDSuite WString.
         */
        if (!s_hudText) {
            return;
        }

        /*
         * Placeholder for later:
         *   paf::WString text;
         *   text.Set(...), or use whichever real setter the headers expose.
         *   s_hudText->SetString(text);
         */
    }

    void Hud::Update(void *arg)
    {
        (void)arg;

        if (!g_settings.hudEnabled) {
            return;
        }

        UpdateCachedText();
        ApplyText();
    }
}
